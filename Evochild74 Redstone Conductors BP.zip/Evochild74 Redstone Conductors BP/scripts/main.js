import { system, world, MolangVariableMap, BlockPermutation } from "@minecraft/server";
import { ModalFormData, ActionFormData, FormCancelationReason } from "@minecraft/server-ui";

// ---------------------------------------------------------------------------
// evo74 redstone blocks — one custom component, two block types
//
//   redstone_emitter : input set on placement, pass-through output, extra
//                      output faces auto-open when another block is placed
//                      against it. Delay applies to turn-on only.
//   redstone_repeater: input set on placement, output fixed to the opposite
//                      face. Delay applies to BOTH edges so pulses pass
//                      through intact (vanilla repeater behaviour).
//
//   power : block state 1..15 (default 15), redstone strength while lit
//   delay : dynamic property per position, in game ticks
// Config in-game: interact with an empty hand or the wrench -> form.
// ---------------------------------------------------------------------------
const NS = "evo74";
const EMITTER_ID = `${NS}:redstone_emitter`;
const REPEATER_ID = `${NS}:redstone_repeater`;
const PULSER_ID = `${NS}:redstone_pulser`;
const SENSOR_ID = `${NS}:redstone_sensor`;
const POST_ID = `${NS}:conduit_post`;
const ELEVATOR_ID = `${NS}:elevator_floor`;
const SHAFT_ID = `${NS}:elevator_shaft`;
const STOP_ID = `${NS}:elevator_stop`;
const MAX_CAR = 64;
const CAR_ENTITY = `${NS}:elevator_car`;
const CAR_SPEED = 2.5;      // blocks per second
const CAR_TICK = 1;         // update interval in ticks
const CAR_SLAB_TOP = 1.0;   // top-half slab: surface at block y + 1
const ST_DIR = `${NS}:dir`;
const LED_ID = `${NS}:led_lamp`;
const DOOR_ID = `${NS}:elevator_door`;
const DOOR_L_ID = `${NS}:elevator_door_left`;
const DOOR_R_ID = `${NS}:elevator_door_right`;
const DOOR_IDS = new Set([DOOR_L_ID, DOOR_R_ID]);
const DOOR_KIND = { [DOOR_L_ID]: "left", [DOOR_R_ID]: "right" };
const OPEN_DOORS_KEY = `${NS}:open_doors`;
const CALL_ID = `${NS}:call_button`;
const ST_FACING = `${NS}:facing`;
const ST_LIT = `${NS}:lit`;
const CALL_SEARCH = 6;   // blocks around the button to look for a Stop
const CALL_SCAN_Y = 64;  // how far up/down a shaft to look for the car // JSON array of {d,x,y,z,axis,side}
const ST_AXIS = `${NS}:axis`;
const PANEL_ENTITY = `${NS}:door_panel`;
const DOOR_ANIM_TICKS = 8; // 0.4 s
const DOOR_RANGE = 3;   // horizontal reach from a slab to its doors
const DOOR_LO = 1;      // slab is a top-half block: doors start one block above its coordinate
const DOOR_UP = 2;      // ... and run up to slab + DOOR_UP (a 2-high doorway)
const ST_BRIGHT = `${NS}:brightness`;
const ST_BATTERY = `${NS}:battery`;
const RGB_ID = `${NS}:rgb_panel`;
const ST_COLOR = `${NS}:color`;
const RGB_COLORS = ["white","red","orange","yellow","lime","green","cyan","light_blue","blue","purple","magenta","pink","brown","gray","black","amber"];
const WRENCH_IDS = new Set([`${NS}:redstone_wrench`, `${NS}:emitter_wrench`]);
const ST_INPUT = `${NS}:input_face`;
const ST_POWERED = `${NS}:is_powered`;
const ST_POWER = `${NS}:power`;
const ST_OMNI = `${NS}:omni`;
const FACES = ["down", "up", "north", "south", "east", "west"];
const OPPOSITE = { down: "up", up: "down", north: "south", south: "north", east: "west", west: "east" };
const SETTLE_TICKS = 2;
const MAX_DELAY = 200; // ticks (10 s)
const DEFAULT_DELAY = { [EMITTER_ID]: 0, [REPEATER_ID]: 2, [PULSER_ID]: 10, [SENSOR_ID]: 0 };
const SENSOR_MAX = 16;
const MAX_REACH = 16;
const SENSOR_DEFAULTS = { w: 1, h: 1, d: 1, ox: 0, oy: 1, oz: 0, creative: false };

function isOurs(b) {
  return b !== undefined && (b.typeId === EMITTER_ID || b.typeId === REPEATER_ID ||
                             b.typeId === PULSER_ID || b.typeId === SENSOR_ID || b.typeId === POST_ID);
}

function outState(face) {
  return `${NS}:out_${face}`;
}

function neighborOn(block, face) {
  switch (face) {
    case "down": return block.below();
    case "up": return block.above();
    case "north": return block.north();
    case "south": return block.south();
    case "east": return block.east();
    case "west": return block.west();
  }
  return undefined;
}

function keyOf(b) {
  return `${b.dimension.id}:${b.location.x},${b.location.y},${b.location.z}`;
}

// Direction enum values are "Down", "Up", ... -> our lowercase state values
function dirToFace(dir) {
  return typeof dir === "string" ? dir.toLowerCase() : undefined;
}

// Set input face on a permutation; emitter also gets a pass-through output.
function orient(perm, input) {
  if (perm.type.id === POST_ID && input !== "up" && input !== "down") input = "down";
  let p = perm.withState(ST_INPUT, input);
  if (perm.type.id === EMITTER_ID) {
    for (const f of FACES) p = p.withState(outState(f), f === OPPOSITE[input]);
  }
  return p;
}

// Does `block` emit on `face`?
function emitsOn(block, face) {
  if (block.typeId === POST_ID) {
    return OPPOSITE[block.permutation.getState(ST_INPUT)] === face;
  }
  if (block.typeId === REPEATER_ID || block.typeId === PULSER_ID) {
    const input = block.permutation.getState(ST_INPUT);
    if (block.permutation.getState(ST_OMNI) === true) return input !== face;
    return OPPOSITE[input] === face;
  }
  if (block.typeId === SENSOR_ID) {
    return block.permutation.getState(ST_INPUT) !== face;
  }
  return block.permutation.getState(outState(face)) === true;
}

// --- delay stored per block position ---------------------------------------
function delayKey(b) {
  return `${NS}:delay:${keyOf(b)}`;
}
function getDelay(b) {
  const v = world.getDynamicProperty(delayKey(b));
  return typeof v === "number" ? v : (DEFAULT_DELAY[b.typeId] ?? 0);
}
function setDelay(b, ticks) {
  world.setDynamicProperty(delayKey(b), ticks);
}
function reachKey(b) {
  return `${NS}:reach:${keyOf(b)}`;
}
function getReach(b) {
  const v = world.getDynamicProperty(reachKey(b));
  return typeof v === "number" ? v : 1;
}
function setReach(b, n) {
  world.setDynamicProperty(reachKey(b), n > 1 ? n : undefined);
}

// --- pulser config: { on, off, count } ---------------------------------------------
const PULSER_DEFAULTS = { on: 2, off: 8, count: 0 }; // count 0 = forever while input held
const MAX_PULSE_COUNT = 64;
function pulserKey(b) { return `${NS}:pulser:${keyOf(b)}`; }
function getPulserCfg(b) {
  try {
    const v = world.getDynamicProperty(pulserKey(b));
    if (typeof v === "string") return { ...PULSER_DEFAULTS, ...JSON.parse(v) };
  } catch {}
  return { ...PULSER_DEFAULTS };
}
function setPulserCfg(b, cfg) {
  world.setDynamicProperty(pulserKey(b), JSON.stringify(cfg));
}

// --- wave config (repeater, wave mode): { lo, hi } -----------------------------------
const WAVE_DEFAULTS = { lo: 1, hi: 15 };
function waveKey(b) { return `${NS}:wave:${keyOf(b)}`; }
function getWaveCfg(b) {
  try {
    const v = world.getDynamicProperty(waveKey(b));
    if (typeof v === "string") return { ...WAVE_DEFAULTS, ...JSON.parse(v) };
  } catch {}
  return { ...WAVE_DEFAULTS };
}
function setWaveCfg(b, cfg) {
  world.setDynamicProperty(waveKey(b), JSON.stringify(cfg));
}

function clearDelay(b) {
  world.setDynamicProperty(delayKey(b), undefined);
  world.setDynamicProperty(reachKey(b), undefined);
  world.setDynamicProperty(pulserKey(b), undefined);
  world.setDynamicProperty(waveKey(b), undefined);
  world.setDynamicProperty(modeKey(b), undefined);
  world.setDynamicProperty(sensorKey(b), undefined);
}

// --- sensor config: { w, h, d, off, creative } ---------------------------------
function sensorKey(b) {
  return `${NS}:sensor:${keyOf(b)}`;
}
function getSensorCfg(b) {
  try {
    const v = world.getDynamicProperty(sensorKey(b));
    if (typeof v === "string") {
      const { off, ...rest } = JSON.parse(v);
      return { ...SENSOR_DEFAULTS, ...rest };
    }
  } catch {}
  return { ...SENSOR_DEFAULTS };
}
function setSensorCfg(b, cfg) {
  world.setDynamicProperty(sensorKey(b), JSON.stringify(cfg));
}

// --- repeater mode -------------------------------------------------------------
//   pulse  : while input is on, output toggles every `delay` ticks (clock)
//   delay  : pass-through, both edges delayed by `delay` (vanilla repeater)
//   invert : output is NOT(input), delayed (NOT gate)
const MODES = ["delay", "invert", "wave"]; // repeater modes; the pulser block is always "pulse"
const DEFAULT_MODE = "delay";
function modeKey(b) {
  return `${NS}:mode:${keyOf(b)}`;
}
function getMode(b) {
  if (b.typeId === PULSER_ID) return "pulse";
  const v = world.getDynamicProperty(modeKey(b));
  return MODES.includes(v) ? v : DEFAULT_MODE;
}
function setMode(b, mode) {
  world.setDynamicProperty(modeKey(b), mode === DEFAULT_MODE ? undefined : mode);
}

// Vanilla blocks that consume redstone. An emitter face touching one is treated as an
// open output, so lamps/doors/pistons work without an extra emitter in between.
const CONSUMERS = /^minecraft:(lit_redstone_lamp|redstone_lamp|.*_door|.*_trapdoor|.*fence_gate|piston|sticky_piston|dispenser|dropper|hopper|noteblock|note_block|tnt|bell|golden_rail|activator_rail|rail|powered_repeater|unpowered_repeater|powered_comparator|unpowered_comparator|redstone_wire|copper_bulb|.*_copper_bulb|crafter|command_block|chain_command_block|repeating_command_block|structure_block|observer|.*_lantern|sculk_shrieker)$/;

// Faces the emitter should currently output on: explicitly opened ones plus any face
// touching a vanilla redstone consumer.
function desiredOutputs(block) {
  const input = block.permutation.getState(ST_INPUT);
  const out = {};
  for (const f of FACES) {
    if (f === input) { out[f] = false; continue; }
    let on = block.permutation.getState(outState(f)) === true;
    if (!on) {
      const n = neighborOn(block, f);
      if (n && CONSUMERS.test(n.typeId)) on = true;
    }
    out[f] = on;
  }
  return out;
}

// Open any emitter faces that now touch a consumer (never closes faces).
function syncEmitterOutputs(block) {
  if (block.typeId !== EMITTER_ID) return;
  const want = desiredOutputs(block);
  let p = block.permutation, changed = false;
  for (const f of FACES) {
    if (want[f] && p.getState(outState(f)) !== true) { p = p.withState(outState(f), true); changed = true; }
  }
  if (changed) block.setPermutation(p);
}

// Genuine power sources: the only things that can drive an input.
const RESET_SOURCES = /^minecraft:(lever|.*_button|redstone_torch|unlit_redstone_torch|redstone_wire|redstone_block|powered_repeater|unpowered_repeater|powered_comparator|unpowered_comparator|observer|.*pressure_plate|tripwire_hook|daylight_detector|daylight_detector_inverted|target|lectern|lightning_rod|trapped_chest|detector_rail|jukebox|sculk_sensor|calibrated_sculk_sensor)$/;

// Scan up to `reach` blocks along the input direction; the first source found decides.
// Returns true/false, or undefined when nothing qualifying is in range.
// Diagnostic: describe what the scan would see.
function describeInput(block) {
  const inputFace = block.permutation.getState(ST_INPUT);
  let cur = block;
  for (let i = 1; i <= getReach(block); i++) {
    cur = neighborOn(cur, inputFace);
    if (!cur) return "src=none";
    if (isOurs(cur) || RESET_SOURCES.test(cur.typeId)) {
      return `src=${cur.typeId.replace("minecraft:", "").replace(`${NS}:`, "")}@${i} pow=${cur.getRedstonePower?.()}`;
    }
  }
  return "src=none";
}

function scanInput(block, reach) {
  const inputFace = block.permutation.getState(ST_INPUT);
  const faceTowardUs = OPPOSITE[inputFace];
  let cur = block;
  for (let i = 1; i <= reach; i++) {
    cur = neighborOn(cur, inputFace);
    if (!cur) return undefined;
    if (isOurs(cur)) {
      return cur.permutation.getState(ST_POWERED) === true && emitsOn(cur, faceTowardUs);
    }
    // Only genuine sources count. A plain block (or air) next to a lit emitter reads the
    // emitter's own output back, which would latch it on.
    if (RESET_SOURCES.test(cur.typeId)) return (cur.getRedstonePower() ?? 0) > 0;
  }
  return undefined;
}

// Is this block receiving power on its configured input face?
function isInputPowered(block) {
  return scanInput(block, getReach(block)) === true;
}

// Sensor reset: genuine sources only, so air/stone behind it can't echo its own output.
function isResetPowered(block) {
  return scanInput(block, getReach(block)) === true;
}

function setLit(b, value) {
  if (b.permutation.getState(ST_POWERED) !== value) {
    b.setPermutation(b.permutation.withState(ST_POWERED, value));
  }
}

// --- state transitions -------------------------------------------------------
// Emitter: delay on turn-on only, turn-off immediate.
const armed = new Set();
function evaluateEmitter(block) {
  const lit = block.permutation.getState(ST_POWERED) === true;
  const want = isInputPowered(block);
  if (lit === want) return;
  if (!want) return setLit(block, false);

  const delay = getDelay(block);
  if (delay <= 0) return setLit(block, true);

  const key = keyOf(block);
  if (armed.has(key)) return;
  armed.add(key);
  const { dimension, location } = block;
  system.runTimeout(() => {
    armed.delete(key);
    const b = dimension.getBlock(location);
    if (isOurs(b) && isInputPowered(b)) setLit(b, true);
  }, delay);
}

// Repeater, delay/invert modes: every input change is queued and applied after
// the delay, so a pulse narrower than the delay still comes out the other side.
const lastTarget = new Map(); // key -> last queued/applied value
function evaluateRepeaterDelayed(block, invert) {
  const key = keyOf(block);
  const want = invert ? !isInputPowered(block) : isInputPowered(block);
  const prev = lastTarget.has(key) ? lastTarget.get(key) : block.permutation.getState(ST_POWERED) === true;
  if (want === prev) return;
  lastTarget.set(key, want);

  const delay = getDelay(block);
  const { dimension, location } = block;
  const apply = () => {
    const b = dimension.getBlock(location);
    if (isOurs(b)) setLit(b, want);
  };
  if (delay <= 0) apply();
  else system.runTimeout(apply, delay);
}

// Pulser: on/off phases with an optional pulse count per rising edge of the input.
const pulsers = new Map();     // key -> timeout handle
const pulserDone = new Set();  // keys that have finished their count and await input release
function stopPulser(key) {
  const h = pulsers.get(key);
  if (h !== undefined) {
    system.clearRun(h);
    pulsers.delete(key);
  }
}
function evaluateRepeaterPulse(block) {
  const key = keyOf(block);
  if (!isInputPowered(block)) {
    stopPulser(key);
    pulserDone.delete(key);
    setLit(block, false);
    return;
  }
  if (pulsers.has(key) || pulserDone.has(key)) return;

  const { dimension, location } = block;
  const cfg = getPulserCfg(block);
  let fired = 0;
  const phase = (on) => {
    const b = dimension.getBlock(location);
    if (!isOurs(b) || getMode(b) !== "pulse" || !isInputPowered(b)) {
      pulsers.delete(key);
      if (isOurs(b)) setLit(b, false);
      return;
    }
    if (on) {
      if (cfg.count > 0 && fired >= cfg.count) {
        pulsers.delete(key);
        pulserDone.add(key);   // wait for the input to drop before re-arming
        setLit(b, false);
        return;
      }
      fired++;
      setLit(b, true);
      pulsers.set(key, system.runTimeout(() => phase(false), Math.max(1, cfg.on)));
    } else {
      setLit(b, false);
      pulsers.set(key, system.runTimeout(() => phase(true), Math.max(1, cfg.off)));
    }
  };
  phase(true);
}

// Wave: while the input is on, output power sweeps lo..hi..lo, one step per `delay` ticks.
const wavers = new Map(); // key -> timeout handle
function stopWaver(key) {
  const h = wavers.get(key);
  if (h !== undefined) {
    system.clearRun(h);
    wavers.delete(key);
  }
}
function evaluateRepeaterWave(block) {
  const key = keyOf(block);
  if (!isInputPowered(block)) {
    stopWaver(key);
    setLit(block, false);
    return;
  }
  if (wavers.has(key)) return;

  const { dimension, location } = block;
  const { lo, hi } = getWaveCfg(block);
  const min = Math.min(lo, hi), max = Math.max(lo, hi);
  let level = min, dir = 1;
  const step = () => {
    const b = dimension.getBlock(location);
    if (!isOurs(b) || getMode(b) !== "wave" || !isInputPowered(b)) {
      wavers.delete(key);
      if (isOurs(b)) setLit(b, false);
      return;
    }
    let p = b.permutation.withState(ST_POWER, level).withState(ST_POWERED, true);
    b.setPermutation(p);
    if (max > min) {
      if (level >= max) dir = -1;
      else if (level <= min) dir = 1;
      level += dir;
    }
    wavers.set(key, system.runTimeout(step, Math.max(1, getDelay(b))));
  };
  step();
}

function evaluateRepeater(block) {
  const mode = getMode(block);
  if (mode === "pulse") return evaluateRepeaterPulse(block);
  if (mode === "wave") { stopPulser(keyOf(block)); return evaluateRepeaterWave(block); }
  stopWaver(keyOf(block));
  stopPulser(keyOf(block));
  evaluateRepeaterDelayed(block, mode === "invert");
}

// --- sensor ----------------------------------------------------------------------

// Axis-aligned detection box in block coords: origin = sensor + (ox, oy, oz),
// extending +X by w, +Y by h, +Z by d. {min, max} inclusive.
function sensorBox(block) {
  const cfg = getSensorCfg(block);
  const o = block.location;
  const min = { x: o.x + cfg.ox, y: o.y + cfg.oy, z: o.z + cfg.oz };
  const max = { x: min.x + cfg.w - 1, y: min.y + cfg.h - 1, z: min.z + cfg.d - 1 };
  return { min, max, cfg };
}

function playerInBox(block) {
  const { min, max, cfg } = sensorBox(block);
  const players = block.dimension.getPlayers({
    location: min,
    volume: { x: max.x - min.x + 1, y: max.y - min.y + 1, z: max.z - min.z + 1 },
  });
  for (const pl of players) {
    if (!cfg.creative && pl.getGameMode?.() === "Creative") continue;
    // getPlayers volume is loose at the edges; confirm against feet position
    const l = pl.location;
    if (l.x >= min.x && l.x < max.x + 1 && l.y >= min.y - 0.5 && l.y < max.y + 1 &&
        l.z >= min.z && l.z < max.z + 1) return true;
  }
  return false;
}

// Latch: reset input held -> forced off. Otherwise any player in the box -> on, stays on.
function evaluateSensor(block) {
  const lit = block.permutation.getState(ST_POWERED) === true;
  const reset = isResetPowered(block);
  const inBox = playerInBox(block);
  if (reset) { setLit(block, false); return; }
  if (!lit && inBox) setLit(block, true);
}

// Outline the box with particles for anyone nearby holding the wrench.
function showSensorBox(block) {
  let holders = [];
  try {
    holders = block.dimension.getPlayers({ location: block.location, maxDistance: 32 }).filter((pl) => {
      const inv = pl.getComponent("minecraft:inventory")?.container;
      const held = inv?.getItem(pl.selectedSlotIndex);
      return held !== undefined && WRENCH_IDS.has(held.typeId);
    });
  } catch (err) {
    console.warn(`[evo74] sensor holder check failed: ${err}`);
    return;
  }
  if (holders.length === 0) return;
  const { min, max } = sensorBox(block);
  const lo = { x: min.x, y: min.y, z: min.z }, hi = { x: max.x + 1, y: max.y + 1, z: max.z + 1 };
  const spawn = (x, y, z) => {
    try { block.dimension.spawnParticle("minecraft:villager_happy", { x, y, z }); } catch {}
  };
  const step = 0.5;
  for (let x = lo.x; x <= hi.x; x += step) for (const y of [lo.y, hi.y]) for (const z of [lo.z, hi.z]) spawn(x, y, z);
  for (let y = lo.y; y <= hi.y; y += step) for (const x of [lo.x, hi.x]) for (const z of [lo.z, hi.z]) spawn(x, y, z);
  for (let z = lo.z; z <= hi.z; z += step) for (const x of [lo.x, hi.x]) for (const y of [lo.y, hi.y]) spawn(x, y, z);
}

function evaluate(block) {
  if (!isOurs(block)) return;
  if (block.typeId === SENSOR_ID) evaluateSensor(block);
  else if (block.typeId === REPEATER_ID || block.typeId === PULSER_ID) evaluateRepeater(block);
  else if (block.typeId === POST_ID) setLit(block, isInputPowered(block));
  else evaluateEmitter(block);
}

const pending = new Set();
function scheduleEvaluate(block) {
  if (!isOurs(block)) return;
  const key = keyOf(block);
  if (pending.has(key)) return;
  pending.add(key);
  const { dimension, location } = block;
  system.runTimeout(() => {
    pending.delete(key);
    evaluate(dimension.getBlock(location));
  }, SETTLE_TICKS);
}

// Any of our blocks whose input points at `block` needs re-evaluation when `block` changes
function scheduleDependents(block) {
  for (const f of FACES) {
    const n = neighborOn(block, f);
    if (isOurs(n) && n.permutation.getState(ST_INPUT) === OPPOSITE[f]) scheduleEvaluate(n);
  }
}

// Auto-connect: if `block`'s input faces an emitter, open that emitter's face toward it.
function autoConnect(block) {
  const input = block.permutation.getState(ST_INPUT);
  const src = neighborOn(block, input);
  if (src && src.typeId === EMITTER_ID) {
    const faceTowardUs = OPPOSITE[input];
    if (src.permutation.getState(ST_INPUT) !== faceTowardUs && !emitsOn(src, faceTowardUs)) {
      src.setPermutation(src.permutation.withState(outState(faceTowardUs), true));
    }
  }
}

// ---------------------------------------------------------------------------
// Block custom component (shared by both block types)
// ---------------------------------------------------------------------------
const RedstoneComponent = {
  // Orientation on placement:
  //  - placed against one of our blocks or a redstone source -> that side is the input
  //  - otherwise the input is the side nearest the player and the output points
  //    the way the player is looking (repeater-style)
  beforeOnPlayerPlace(e) {
    const clickedFace = dirToFace(e.face);
    if (!clickedFace || !FACES.includes(clickedFace)) return;
    const clicked = neighborOn(e.block, OPPOSITE[clickedFace]);
    let input = OPPOSITE[clickedFace];

    if (e.permutationToPlace.type.id === POST_ID) {
      // vertical only: placed on a ceiling (clicked face is down) -> input from above
      e.permutationToPlace = e.permutationToPlace.withState(ST_INPUT, clickedFace === "down" ? "up" : "down");
      return;
    }
    const againstSource = clicked && (isOurs(clicked) || RESET_SOURCES.test(clicked.typeId));
    if (!againstSource && e.player) {
      const v = e.player.getViewDirection();
      if (v.y < -0.7) input = "up";
      else if (v.y > 0.7) input = "down";
      else if (Math.abs(v.x) > Math.abs(v.z)) input = v.x > 0 ? "west" : "east";
      else input = v.z > 0 ? "north" : "south";
    }
    e.permutationToPlace = orient(e.permutationToPlace, input);
  },
  onPlace(e) {
    autoConnect(e.block);
    scheduleEvaluate(e.block);
  },
  onBlockStateChange(e) {
    scheduleDependents(e.block);
  },
  onBreak(e) {
    clearDelay(e.block);
    lastTarget.delete(keyOf(e.block));
    stopPulser(keyOf(e.block));
    stopWaver(keyOf(e.block));
    pulserDone.delete(keyOf(e.block));
    scheduleDependents(e.block);
  },
  onTick(e) {
    // Polling carries the chain; onBlockStateChange is only a fast path.
    if (e.block.typeId === SENSOR_ID) showSensorBox(e.block);
    if (e.block.typeId === EMITTER_ID) syncEmitterOutputs(e.block);
    scheduleEvaluate(e.block);
  },
};

// ---------------------------------------------------------------------------
// Config form: power + delay
// ---------------------------------------------------------------------------
function isConfigTool(stack) {
  return stack === undefined || WRENCH_IDS.has(stack.typeId);
}

// Forms shown right after an interaction are often auto-cancelled as UserBusy; retry briefly.
async function showForm(form, player, tries = 20) {
  for (let i = 0; i < tries; i++) {
    const res = await form.show(player);
    if (res.cancelationReason !== FormCancelationReason.UserBusy) return res;
    await new Promise((r) => system.runTimeout(r, 2));
  }
  return { canceled: true };
}

// One open form per player; the interact event fires repeatedly for a single click.
const formOpen = new Set();

function openConfigForm(player, block) {
  if (formOpen.has(player.id)) return;
  formOpen.add(player.id);
  const release = () => formOpen.delete(player.id);

  let form, isSensor, isRepeater;
  try {
    const title = block.typeId === POST_ID ? "Conduit Post"
              : block.typeId === SENSOR_ID ? "Redstone Sensor"
                : block.typeId === PULSER_ID ? "Redstone Pulser"
                : block.typeId === REPEATER_ID ? "Redstone Repeater" : "Redstone Emitter";
    const power = block.permutation.getState(ST_POWER) ?? 15;
    isSensor = block.typeId === SENSOR_ID;
    isRepeater = block.typeId === REPEATER_ID;

    form = new ModalFormData().title(title);
    form.slider("Power", 1, 15, { valueStep: 1, defaultValue: power });
    form.slider("Input reach (blocks)", 1, MAX_REACH, { valueStep: 1, defaultValue: getReach(block) });
    if (isSensor) {
      const c = getSensorCfg(block);
      form.slider("Width (+X)", 1, SENSOR_MAX, { valueStep: 1, defaultValue: c.w });
      form.slider("Height (+Y)", 1, SENSOR_MAX, { valueStep: 1, defaultValue: c.h });
      form.slider("Depth (+Z)", 1, SENSOR_MAX, { valueStep: 1, defaultValue: c.d });
      form.slider("Offset X", -SENSOR_MAX, SENSOR_MAX, { valueStep: 1, defaultValue: c.ox });
      form.slider("Offset Y", -SENSOR_MAX, SENSOR_MAX, { valueStep: 1, defaultValue: c.oy });
      form.slider("Offset Z", -SENSOR_MAX, SENSOR_MAX, { valueStep: 1, defaultValue: c.oz });
      form.toggle("Trigger on creative players", { defaultValue: c.creative });
    } else if (block.typeId === PULSER_ID) {
      const c = getPulserCfg(block);
      form.slider("Pulse on (ticks)", 1, MAX_DELAY, { valueStep: 1, defaultValue: c.on });
      form.slider("Pulse off (ticks)", 1, MAX_DELAY, { valueStep: 1, defaultValue: c.off });
      form.slider("Pulse count (0 = forever)", 0, MAX_PULSE_COUNT, { valueStep: 1, defaultValue: c.count });
      form.toggle("Omni output (all faces but input)", { defaultValue: block.permutation.getState(ST_OMNI) === true });
    } else if (block.typeId === POST_ID) {
      // power + reach only
    } else {
      form.slider("Delay (ticks, 20 = 1s)", 0, MAX_DELAY, { valueStep: 2, defaultValue: getDelay(block) });
      if (isRepeater) {
        form.toggle("Omni output (all faces but input)", { defaultValue: block.permutation.getState(ST_OMNI) === true });
      }
    }
    if (isRepeater) {
      form.dropdown("Mode", ["Delay (pass-through)", "Invert (NOT gate)", "Wave (sweep power)"],
        { defaultValueIndex: Math.max(0, MODES.indexOf(getMode(block))) });
      const w = getWaveCfg(block);
      form.slider("Wave low", 1, 15, { valueStep: 1, defaultValue: w.lo });
      form.slider("Wave high", 1, 15, { valueStep: 1, defaultValue: w.hi });
    }
    form.submitButton("Apply");
  } catch (err) {
    release();
    console.warn(`[evo74] form build failed: ${err}`);
    return;
  }

  showForm(form, player).then((res) => {
    if (res.canceled || !res.formValues) return;
    const b = block.dimension.getBlock(block.location);
    if (!isOurs(b)) return;
    const v = res.formValues;
    const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n | 0));
    b.setPermutation(b.permutation.withState(ST_POWER, clamp(v[0], 1, 15)));
    setReach(b, clamp(v[1], 1, MAX_REACH));
    if (isSensor) {
      setSensorCfg(b, {
        w: clamp(v[2], 1, SENSOR_MAX), h: clamp(v[3], 1, SENSOR_MAX), d: clamp(v[4], 1, SENSOR_MAX),
        ox: clamp(v[5], -SENSOR_MAX, SENSOR_MAX), oy: clamp(v[6], -SENSOR_MAX, SENSOR_MAX),
        oz: clamp(v[7], -SENSOR_MAX, SENSOR_MAX),
        creative: v[8] === true,
      });
    } else if (b.typeId === PULSER_ID) {
      setPulserCfg(b, {
        on: clamp(v[2], 1, MAX_DELAY), off: clamp(v[3], 1, MAX_DELAY),
        count: clamp(v[4], 0, MAX_PULSE_COUNT),
      });
      b.setPermutation(b.permutation.withState(ST_OMNI, v[5] === true));
      stopPulser(keyOf(b));
      pulserDone.delete(keyOf(b));
    } else if (b.typeId === POST_ID) {
      // nothing beyond power + reach
    } else {
      setDelay(b, clamp(v[2], 0, MAX_DELAY));
      let p = b.permutation;
      if (isRepeater) p = p.withState(ST_OMNI, v[3] === true);
      if (p !== b.permutation) b.setPermutation(p);
      if (isRepeater) {
        setMode(b, MODES[v[4] | 0] ?? DEFAULT_MODE);
        setWaveCfg(b, { lo: clamp(v[5], 1, 15), hi: clamp(v[6], 1, 15) });
        stopPulser(keyOf(b));
        stopWaver(keyOf(b));
        lastTarget.delete(keyOf(b));
      }
    }
    scheduleEvaluate(b);
    scheduleDependents(b);
  }).catch((err) => {
    console.warn(`[evo74] form failed: ${err}`);
  }).finally(release);
}

world.beforeEvents.playerInteractWithBlock.subscribe((e) => {
  const { block, player, itemStack } = e;
  if (!isOurs(block)) return;
  console.log(`[evo74] interact block=${block.typeId} item=${itemStack?.typeId ?? "(empty)"} tool=${isConfigTool(itemStack)}`);
  if (!isConfigTool(itemStack)) return; // holding a block -> normal placement
  e.cancel = true;
  if (player.isSneaking) {
    // Sneak + wrench: flip the block (input and output swap).
    system.run(() => {
      const b = block.dimension.getBlock(block.location);
      if (!isOurs(b)) return;
      const next = OPPOSITE[b.permutation.getState(ST_INPUT)];
      b.setPermutation(orient(b.permutation, next));
      autoConnect(b);
      player.onScreenDisplay.setActionBar(`input: ${next}  output: ${OPPOSITE[next]}`);
      scheduleEvaluate(b);
      scheduleDependents(b);
    });
    return;
  }
  system.run(() => {
    const b = block.dimension.getBlock(block.location);
    if (!isOurs(b)) return;
    const outs = FACES.filter((f) => emitsOn(b, f)).join(",");
    player.onScreenDisplay.setActionBar(
      `in=${b.permutation.getState(ST_INPUT)} out=[${outs}] lit=${b.permutation.getState(ST_POWERED)} reach=${getReach(b)} ${describeInput(b)}`);
    openConfigForm(player, b);
  });
});

// ---------------------------------------------------------------------------
// Elevator floor: right-click -> Up / Down / Stop. Travels one block per tick-interval
// while a shaft block touches the destination level on any side and the way is clear.
// Carries players standing on it. Independent of redstone.
// ---------------------------------------------------------------------------
const SIDES = ["north", "south", "east", "west"];

function sideTypesAt(dimension, loc) {
  const b = dimension.getBlock(loc);
  if (!b) return new Set();
  const out = new Set();
  for (const f of SIDES) {
    const n = neighborOn(b, f);
    if (n) out.add(n.typeId);
  }
  return out;
}

function clear(dimension, loc) {
  const b = dimension.getBlock(loc);
  // doors count as clear: they open on arrival
  return b !== undefined && (b.isAir || b.isLiquid || DOOR_IDS.has(b.typeId));
}

// All floor blocks connected horizontally to `block` (same Y), including itself.
function carBlocks(block) {
  const { dimension, location } = block;
  const start = `${location.x},${location.z}`;
  const seen = new Set([start]);
  const queue = [block];
  const out = [];
  while (queue.length && out.length < MAX_CAR) {
    const b = queue.shift();
    out.push(b);
    for (const f of SIDES) {
      const n = neighborOn(b, f);
      if (!n || n.typeId !== ELEVATOR_ID) continue;
      const k = `${n.location.x},${n.location.z}`;
      if (seen.has(k)) continue;
      seen.add(k);
      queue.push(n);
    }
  }
  return out;
}

function passengersOnCar(dimension, blocks) {
  const out = [];
  const seen = new Set();
  for (const b of blocks) {
    const { location } = b;
    const found = dimension.getEntities({
      location: { x: location.x + 0.5, y: location.y + 0.5, z: location.z + 0.5 },
      maxDistance: 2.5,
      excludeTypes: ["minecraft:player", CAR_ENTITY],
    });
    for (const en of found) {
      if (seen.has(en.id)) continue;
      const l = en.location;
      if (l.x >= location.x - 0.3 && l.x < location.x + 1.3 && l.z >= location.z - 0.3 && l.z < location.z + 1.3 &&
          l.y >= location.y + 0.4 && l.y <= location.y + 1.7) {
        seen.add(en.id);
        out.push(en);
      }
    }
  }
  return out;
}

function ridersOnCar(dimension, blocks) {
  const riders = [];
  const seen = new Set();
  for (const b of blocks) {
    const { location } = b;
    for (const pl of dimension.getPlayers({ location, volume: { x: 1, y: 2, z: 1 } })) {
      if (seen.has(pl.id)) continue;
      const l = pl.location;
      // top-half slab: riders stand at location.y + 1
      if (l.x >= location.x && l.x < location.x + 1 && l.z >= location.z && l.z < location.z + 1 &&
          l.y >= location.y + 0.4 && l.y <= location.y + 1.7) {
        seen.add(pl.id);
        riders.push(pl);
      }
    }
  }
  return riders;
}

// Per-car gate: only the lowest-x,lowest-z block of a car drives it each tick.
function isCarLeader(block, car) {
  const { x, z } = block.location;
  return car.every((b) => b.location.x > x || (b.location.x === x && b.location.z >= z));
}

function setCarDir(car, dir) {
  for (const b of car) {
    try {
      const live = b.dimension.getBlock(b.location);
      if (!live || live.typeId !== ELEVATOR_ID) continue;
      if (live.permutation.getState(ST_DIR) !== dir) live.setPermutation(live.permutation.withState(ST_DIR, dir));
    } catch {}
  }
}

// Can the car (all its slabs) occupy level y? Needs clear cells for slab + 2 headroom
// and at least one shaft/stop beside the level.
function levelOk(dimension, footprint, y, carY) {
  let guided = false;
  for (const { x, z } of footprint) {
    for (let dy = 0; dy <= 2; dy++) {
      const cy = y + dy;
      if (cy === carY) continue; // the car's own slabs don't count as obstruction
      if (!clear(dimension, { x, y: cy, z })) return { ok: false };
    }
    const types = sideTypesAt(dimension, { x, y, z });
    if (types.has(SHAFT_ID) || types.has(STOP_ID)) guided = true;
  }
  return { ok: guided, stop: footprint.some(({ x, z }) => sideTypesAt(dimension, { x, y, z }).has(STOP_ID)) };
}

// Find how far the car can travel in `dy` direction before it must stop (a Stop level or
// the last guided level). Returns the target y, or undefined if it can't move at all.
function findTarget(dimension, footprint, y0, dy) {
  let y = y0, target;
  for (let i = 0; i < 256; i++) {
    const ny = y + dy;
    const r = levelOk(dimension, footprint, ny, y0);
    if (!r.ok) break;
    target = ny; y = ny;
    if (r.stop) break;
  }
  return target;
}

// All Stop levels reachable from y0 (both directions, through intermediate stops),
// sorted ascending. Includes y0 itself if it is a stop level.
function floorLevels(dimension, footprint, y0) {
  const levels = new Set();
  if (levelOk(dimension, footprint, y0, y0).stop ||
      footprint.some(({ x, z }) => sideTypesAt(dimension, { x, y: y0, z }).has(STOP_ID))) levels.add(y0);
  for (const dy of [1, -1]) {
    let y = y0;
    for (let i = 0; i < 256; i++) {
      const ny = y + dy;
      const r = levelOk(dimension, footprint, ny, y0);
      if (!r.ok) break;
      if (r.stop) levels.add(ny);
      y = ny;
    }
  }
  return [...levels].sort((a, b) => a - b);
}

// Ease in/out for position along the ride (0..1 -> 0..1)
function ease(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }

// ---------------------------------------------------------------------------
// Doors: closed = block; open = air + registry entry (so we can put the block back)
// ---------------------------------------------------------------------------
function loadOpenDoors() {
  try { const v = world.getDynamicProperty(OPEN_DOORS_KEY); if (typeof v === "string") return JSON.parse(v); } catch {}
  return [];
}
function saveOpenDoors(list) {
  world.setDynamicProperty(OPEN_DOORS_KEY, list.length ? JSON.stringify(list) : undefined);
}
function doorRecKey(r) { return `${r.d}:${r.x},${r.y},${r.z}`; }

// All door positions (closed blocks + open registry entries) within DOOR_RANGE cube of the car footprint.
function doorsNear(dimension, footprint, y) {
  const out = []; const seen = new Set();
  const inRange = (x, yy, z) => footprint.some(({ x: fx, z: fz }) =>
    Math.abs(x - fx) <= DOOR_RANGE && yy >= y + DOOR_LO && yy <= y + DOOR_UP && Math.abs(z - fz) <= DOOR_RANGE);
  for (const { x, z } of footprint) {
    for (let dx = -DOOR_RANGE; dx <= DOOR_RANGE; dx++)
      for (let dy = DOOR_LO; dy <= DOOR_UP; dy++)
        for (let dz = -DOOR_RANGE; dz <= DOOR_RANGE; dz++) {
          const px = x + dx, py = y + dy, pz = z + dz, k = `${dimension.id}:${px},${py},${pz}`;
          if (seen.has(k)) continue; seen.add(k);
          const b = dimension.getBlock({ x: px, y: py, z: pz });
          if (b && DOOR_IDS.has(b.typeId)) out.push({ d: dimension.id, x: px, y: py, z: pz,
            axis: b.permutation.getState(ST_AXIS) ?? "x", kind: DOOR_KIND[b.typeId], open: false });
        }
  }
  for (const r of loadOpenDoors()) {
    if (r.d !== dimension.id) continue;
    const k = doorRecKey(r);
    if (seen.has(k) || !inRange(r.x, r.y, r.z)) continue;
    seen.add(k); out.push({ ...r, open: true });
  }
  return out;
}

const doorBusy = new Set();

// Panel positions along the span axis (blocks): list of offsets per panel.
function panelTargets(kind) {
  if (kind === "left") return { closed: [0], open: [-1.0], wide: true };
  return { closed: [0], open: [1.0], wide: true };
}

// rec: {d,x,y,z,axis,side,open}
function animateDoor(rec, open) {
  const key = doorRecKey(rec);
  if (doorBusy.has(key) || rec.open === open) return;
  const dimension = world.getDimension(rec.d);
  const location = { x: rec.x, y: rec.y, z: rec.z };
  doorBusy.add(key);

  const { closed, open: opened, wide } = panelTargets(rec.kind);
  const blockId = rec.kind === "left" ? DOOR_L_ID : DOOR_R_ID;
  const from = open ? closed : opened, to = open ? opened : closed;
  const cx = rec.x + 0.5, cz = rec.z + 0.5, y = rec.y;
  const posFor = (off) => rec.axis === "x" ? { x: cx + off, y, z: cz } : { x: cx, y, z: cz + off };

  if (open) {
    // remove the block, remember it, stand a frame entity in its place
    const b = dimension.getBlock(location);
    if (b && DOOR_IDS.has(b.typeId)) b.setType("minecraft:air");

    const list = loadOpenDoors().filter((r) => doorRecKey(r) !== key);
    list.push({ d: rec.d, x: rec.x, y: rec.y, z: rec.z, axis: rec.axis, kind: rec.kind });
    saveOpenDoors(list);
  }

  const panels = [];
  // variants: 2/3 left x/z, 6/7 right x/z
  const variantEvent = rec.kind === "right" ? (rec.axis === "z" ? "evo74:v7" : "evo74:v6")
                                            : (rec.axis === "z" ? "evo74:v3" : "evo74:v2");
  for (let i = 0; i < from.length; i++) {
    try {
      const e = dimension.spawnEntity(PANEL_ENTITY, posFor(from[i]));
      if (variantEvent) { try { e.triggerEvent(variantEvent); } catch {} }
      panels.push(e);
    } catch (err) { console.warn(`[evo74] panel spawn failed: ${err}`); }
  }

  let t = 0;
  const step = () => {
    t++;
    const f = ease(Math.min(1, t / DOOR_ANIM_TICKS));
    panels.forEach((e, i) => { try { e.teleport(posFor(from[i] + (to[i] - from[i]) * f), { dimension, keepVelocity: false }); } catch {} });
    if (t < DOOR_ANIM_TICKS) { system.runTimeout(step, 1); return; }
    for (const e of panels) { try { e.remove(); } catch {} }
    if (!open) {
      const b = dimension.getBlock(location);
      if (b && (b.isAir || b.isLiquid)) {
        b.setPermutation(BlockPermutation.resolve(blockId, { [ST_AXIS]: rec.axis }));
      }
      saveOpenDoors(loadOpenDoors().filter((r) => doorRecKey(r) !== key));
    }
    doorBusy.delete(key);
  };
  system.runTimeout(step, 1);
}

function setDoors(doors, open) {
  for (const d of doors) {
    try { animateDoor(d, open); } catch (err) { console.warn(`[evo74] door set failed: ${err}`); }
  }
}

// Is any parked slab within DOOR_RANGE of (x,y,z)?
// A door at (x,y,z) is served by a slab at y .. y-DOOR_UP within DOOR_RANGE horizontally.
function carNear(dimension, x, y, z) {
  for (let dx = -DOOR_RANGE; dx <= DOOR_RANGE; dx++)
    for (let dy = -DOOR_UP; dy <= -DOOR_LO; dy++)
      for (let dz = -DOOR_RANGE; dz <= DOOR_RANGE; dz++) {
        let b;
        try { b = dimension.getBlock({ x: x + dx, y: y + dy, z: z + dz }); } catch { continue; }
        if (b && b.typeId === ELEVATOR_ID) return true;
      }
  return false;
}

// Open doors have no block to tick, so sweep the registry: close any whose car has left.
system.runInterval(() => {
  const list = loadOpenDoors();
  if (!list.length) return;
  for (const r of list) {
    try {
      const dim = world.getDimension(r.d);
      // skip doors in unloaded chunks (getBlock returns undefined there)
      if (!dim.getBlock({ x: r.x, y: r.y, z: r.z })) continue;
      if (!carNear(dim, r.x, r.y, r.z)) animateDoor({ ...r, open: true }, false);
    } catch {}
  }
}, 8);

const rides = new Set(); // leader keys mid-ride

function startRide(block, dir, explicitY) {
  const car = carBlocks(block);
  const leader = car.find((c) => isCarLeader(c, car));
  if (!leader) return;
  const key = keyOf(leader);
  if (rides.has(key)) return;

  const dimension = leader.dimension;
  const footprint = car.map((b) => ({ x: b.location.x, z: b.location.z }));
  const y0 = leader.location.y;
  let targetY;
  if (explicitY !== undefined) {
    // verify the path is clear all the way (ignoring intermediate stops)
    const step = explicitY > y0 ? 1 : -1;
    let ok = explicitY !== y0;
    for (let y = y0 + step; ok && (step > 0 ? y <= explicitY : y >= explicitY); y += step) {
      if (!levelOk(dimension, footprint, y, y0).ok) ok = false;
    }
    if (ok) targetY = explicitY;
  } else {
    targetY = findTarget(dimension, footprint, y0, dir === "up" ? 1 : -1);
  }
  if (targetY === undefined) { setCarDir(car, "stop"); return; }

  rides.add(key);
  setCarDir(car, "stop"); // blocks will be removed; direction lives in this closure
  setDoors(doorsNear(dimension, footprint, y0), false);

  const riders = ridersOnCar(dimension, car);
  // non-player passengers: remember their offset from the car surface and carry them by teleport
  const passengers = passengersOnCar(dimension, car).map((en) => ({
    en, dx: en.location.x, dz: en.location.z, dyOff: en.location.y - (y0 + CAR_SLAB_TOP),
  }));
  // spawn one entity per slab at its surface; seat riders on the slab under them
  const ents = [];
  for (const b of car) {
    const e = dimension.spawnEntity(CAR_ENTITY, { x: b.location.x + 0.5, y: b.location.y + CAR_SLAB_TOP - 0.5, z: b.location.z + 0.5 });
    ents.push({ e, x: b.location.x, z: b.location.z });
  }
  const seated = new Set();
  for (const pl of riders) {
    const slot = ents.find((o) => pl.location.x >= o.x && pl.location.x < o.x + 1 && pl.location.z >= o.z && pl.location.z < o.z + 1) ?? ents[0];
    try {
      const ok = slot.e.getComponent("minecraft:rideable")?.addRider(pl);
      if (ok) seated.add(pl.id);
      else console.warn(`[evo74] seat refused for ${pl.name}`);
    } catch (err) { console.warn(`[evo74] seat failed: ${err}`); }
  }
  for (const b of car) b.setType("minecraft:air");

  const dist = Math.abs(targetY - y0);
  const totalTicks = Math.max(1, Math.round((dist / CAR_SPEED) * 20));
  let t = 0;
  const step = () => {
    t += CAR_TICK;
    const f = ease(Math.min(1, t / totalTicks));
    const y = y0 + (targetY - y0) * f;
    for (const o of ents) {
      try { o.e.teleport({ x: o.x + 0.5, y: y + CAR_SLAB_TOP - 0.5, z: o.z + 0.5 }, { dimension, keepVelocity: false }); } catch {}
    }
    for (const p of passengers) {
      try {
        const l = p.en.location;
        // keep their own horizontal wandering, pin vertical to the moving surface
        p.en.teleport({ x: l.x, y: y + CAR_SLAB_TOP + Math.max(0, p.dyOff), z: l.z }, { dimension, keepVelocity: false });
      } catch {}
    }
    // riders that are not (or no longer) seated: pin them like passengers so nobody falls through
    for (const pl of riders) {
      try {
        const riding = pl.getComponent("minecraft:riding")?.entityRidingOn;
        if (riding && riding.typeId === CAR_ENTITY) continue;
        const l = pl.location;
        pl.teleport({ x: l.x, y: y + CAR_SLAB_TOP, z: l.z }, { dimension, keepVelocity: false, rotation: pl.getRotation() });
      } catch {}
    }
    if (t < totalTicks) { system.runTimeout(step, CAR_TICK); return; }

    // arrive: eject riders, remove entities, re-materialise blocks
    for (const o of ents) {
      try { o.e.getComponent("minecraft:rideable")?.ejectRiders(); } catch {}
      try { o.e.remove(); } catch {}
    }
    for (const { x, z } of footprint) {
      const nb = dimension.getBlock({ x, y: targetY, z });
      if (nb) nb.setPermutation(BlockPermutation.resolve(ELEVATOR_ID, { [ST_DIR]: "stop" }));
    }
    for (const pl of riders) {
      try {
        const l = pl.location;
        pl.teleport({ x: l.x, y: targetY + CAR_SLAB_TOP, z: l.z }, { dimension, keepVelocity: false, rotation: pl.getRotation() });
        onCar.set(pl.id, false); // re-prompt at the new floor
      } catch {}
    }
    for (const p of passengers) {
      try {
        const l = p.en.location;
        p.en.teleport({ x: l.x, y: targetY + CAR_SLAB_TOP, z: l.z }, { dimension, keepVelocity: false });
      } catch {}
    }
    setDoors(doorsNear(dimension, footprint, targetY), true);
    rides.delete(key);
  };
  system.runTimeout(step, CAR_TICK);
}

// Auto-menu: when a player steps onto a stopped car, show the menu once.
// Sneaking while standing on a stopped car re-opens it.
const onCar = new Map(); // playerId -> car leader key they were last on (or "" if none)
// onCar: playerId -> "riding" while they are on ANY car. Menu opens only on the
// transition from not-riding to riding a STOPPED car, or on sneak while stopped.
const MENU_SETTLE_TICKS = 10;   // must stand centred on the car this long before the menu opens
const MENU_EDGE = 0.2;          // ignore the outer 20% of each slab
const settle = new Map();       // playerId -> ticks spent centred on a stopped car

function centredOnCar(pl, car) {
  const l = pl.location;
  for (const b of car) {
    const fx = l.x - b.location.x, fz = l.z - b.location.z;
    if (fx >= MENU_EDGE && fx <= 1 - MENU_EDGE && fz >= MENU_EDGE && fz <= 1 - MENU_EDGE) return true;
  }
  return false;
}

function elevatorAutoMenu(block) {
  const car = carBlocks(block);
  if (!isCarLeader(block, car)) return;
  const stopped = block.permutation.getState(ST_DIR) === "stop";
  const riders = ridersOnCar(block.dimension, car);
  for (const pl of riders) {
    const wasRiding = onCar.get(pl.id) === true;
    if (!stopped) { onCar.set(pl.id, true); settle.delete(pl.id); continue; }

    if (wasRiding) {
      if (pl.isSneaking && centredOnCar(pl, car)) openElevatorMenu(pl, block);
      continue;
    }
    // not yet counted as riding: accumulate settle time while centred
    if (!centredOnCar(pl, car)) { settle.delete(pl.id); continue; }
    const t = (settle.get(pl.id) ?? 0) + 2; // tick interval is 2
    settle.set(pl.id, t);
    if (t >= MENU_SETTLE_TICKS) {
      settle.delete(pl.id);
      onCar.set(pl.id, true);
      openElevatorMenu(pl, block);
    }
  }
}

// Clear riding flags for players no longer on any car (cheap: once per tick, world-wide).
system.runInterval(() => {
  if (onCar.size === 0) return;
  for (const pl of world.getAllPlayers()) {
    if (!onCar.has(pl.id)) continue;
    const under = pl.dimension.getBlock({ x: Math.floor(pl.location.x), y: Math.floor(pl.location.y - 0.1), z: Math.floor(pl.location.z) });
    if (under?.typeId !== ELEVATOR_ID) { onCar.delete(pl.id); settle.delete(pl.id); }
  }
}, 2);

const ElevatorComponent = {
  onTick(e) {
    const b = e.block.dimension.getBlock(e.block.location);
    if (!b || b.typeId !== ELEVATOR_ID) return;
    elevatorAutoMenu(b);
  },
};

function openElevatorMenu(player, block) {
  if (formOpen.has(player.id)) return;
  formOpen.add(player.id);

  const car = carBlocks(block);
  const footprint = car.map((b) => ({ x: b.location.x, z: b.location.z }));
  const y0 = block.location.y;
  const floors = floorLevels(block.dimension, footprint, y0); // ascending
  const here = floors.indexOf(y0);

  const form = new ActionFormData().title("Elevator");
  form.body(floors.length ? `Floor ${here >= 0 ? here + 1 : "?"} of ${floors.length}` : "No floors found");
  const actions = [];
  // floors listed top-down so the top floor is the first button
  for (let i = floors.length - 1; i >= 0; i--) {
    const label = `Floor ${i + 1}${i === here ? "  (here)" : ""}`;
    form.button(label);
    actions.push({ y: floors[i] });
  }
  form.button("Up (next floor)");    actions.push({ dir: "up" });
  form.button("Down (next floor)");  actions.push({ dir: "down" });

  showForm(form, player).then((res) => {
    if (res.canceled || res.selection === undefined) return;
    const b = block.dimension.getBlock(block.location);
    if (!b || b.typeId !== ELEVATOR_ID) return;
    const a = actions[res.selection];
    if (!a) return;
    if (a.dir) startRide(b, a.dir);
    else if (a.y !== y0) startRide(b, undefined, a.y);
  }).catch((err) => console.warn(`[evo74] elevator menu failed: ${err}`))
    .finally(() => formOpen.delete(player.id));
}

world.beforeEvents.playerInteractWithBlock.subscribe((e) => {
  const { block, player, itemStack } = e;
  if (block.typeId !== ELEVATOR_ID) return;
  // Empty hand or wrench -> menu. Anything else (e.g. a block) behaves normally.
  if (itemStack !== undefined && !WRENCH_IDS.has(itemStack.typeId)) return;
  e.cancel = true;
  system.run(() => openElevatorMenu(player, block));
});

// Door component (closed block only). Doors open only on car ARRIVAL (see startRide);
// proximity never opens them, so placing a door beside a parked car leaves it closed.
function doorEvaluate(_block) {}
const DoorComponent = {
  // Door spans the axis perpendicular to the player's look direction.
  beforeOnPlayerPlace(e) {
    if (!e.player) return;
    const v = e.player.getViewDirection();
    const axis = Math.abs(v.x) > Math.abs(v.z) ? "z" : "x"; // looking along X -> door face spans Z
    e.permutationToPlace = e.permutationToPlace.withState(ST_AXIS, axis);
  },
  onPlace(e) { doorEvaluate(e.block); },
  onTick(e) { doorEvaluate(e.block); },
};

// ---------------------------------------------------------------------------
// Call button: brings the nearest car in a shaft that reaches this floor.
// ---------------------------------------------------------------------------
function findCarForCall(dimension, loc) {
  // 1. find Stop blocks near the button (the floor marker)
  // The button sits at door height; the floor's Stop is at the slab's level, 1..2 below the button.
  const stops = [];
  for (let dx = -CALL_SEARCH; dx <= CALL_SEARCH; dx++)
    for (let dy = -2; dy <= 0; dy++)
      for (let dz = -CALL_SEARCH; dz <= CALL_SEARCH; dz++) {
        let b;
        try { b = dimension.getBlock({ x: loc.x + dx, y: loc.y + dy, z: loc.z + dz }); } catch { continue; }
        if (b && b.typeId === STOP_ID) stops.push(b.location);
      }
  if (!stops.length) return undefined;
  stops.sort((a, b) => (Math.abs(a.x - loc.x) + Math.abs(a.z - loc.z)) - (Math.abs(b.x - loc.x) + Math.abs(b.z - loc.z)));
  // 2. for the nearest stop level, the car column is any horizontally adjacent cell; scan it for a parked slab
  let best;
  const floorY = stops[0].y;
  for (const st of stops.filter((q) => q.y === floorY)) {
    for (const [dx, dz] of [[1,0],[-1,0],[0,1],[0,-1]]) {
      const cx = st.x + dx, cz = st.z + dz;
      const col = dimension.getBlock({ x: cx, y: st.y, z: cz });
      if (!col || !(col.isAir || col.isLiquid || col.typeId === ELEVATOR_ID)) continue;
      const { min: yMin, max: yMax } = dimension.heightRange;
      for (let dy = 0; dy <= CALL_SCAN_Y; dy++) {
        for (const yy of dy === 0 ? [st.y] : [st.y + dy, st.y - dy]) {
          if (yy < yMin || yy >= yMax) continue;
          let b;
          try { b = dimension.getBlock({ x: cx, y: yy, z: cz }); } catch { continue; }
          if (b && b.typeId === ELEVATOR_ID) {
            const dist = Math.abs(yy - st.y);
            if (!best || dist < best.dist) best = { block: b, floorY: st.y, dist };
          }
        }
        if (best && best.dist <= dy) break;
      }
    }
  }
  return best;
}

function pressCall(block, player) {
  const { dimension, location } = block;
  const hit = findCarForCall(dimension, location);
  if (!hit) { player?.onScreenDisplay.setActionBar("No elevator found"); return; }
  if (hit.block.location.y === hit.floorY) { player?.onScreenDisplay.setActionBar("Elevator is here"); return; }
  // light the button until the car arrives
  block.setPermutation(block.permutation.withState(ST_LIT, true));
  startRide(hit.block, undefined, hit.floorY);
  const dist = Math.abs(hit.block.location.y - hit.floorY);
  const eta = Math.round((dist / CAR_SPEED) * 20) + 10;
  system.runTimeout(() => {
    const b = dimension.getBlock(location);
    if (b && b.typeId === CALL_ID) b.setPermutation(b.permutation.withState(ST_LIT, false));
  }, eta);
}

const CallButtonComponent = {
  beforeOnPlayerPlace(e) {
    const face = dirToFace(e.face);
    // mounted on a wall: button faces out from the clicked face
    const facing = ["north", "south", "east", "west"].includes(face) ? face : "north";
    e.permutationToPlace = e.permutationToPlace.withState(ST_FACING, facing);
  },
  onPlayerInteract(e) {
    if (e.player) pressCall(e.block, e.player);
  },
};

// ---------------------------------------------------------------------------
// LED lamp: lights from any redstone input (vanilla lamp semantics), brightness 1..15 via wrench.
// ---------------------------------------------------------------------------
function ledEvaluate(block) {
  const want = block.permutation.getState(ST_BATTERY) === true || (block.getRedstonePower() ?? 0) > 0;
  if ((block.permutation.getState(ST_POWERED) === true) !== want) {
    block.setPermutation(block.permutation.withState(ST_POWERED, want));
  }
}

const LedComponent = {
  onTick(e) { ledEvaluate(e.block); },
  onPlace(e) { ledEvaluate(e.block); },
  onRedstoneUpdate(e) { ledEvaluate(e.block); },
};

function openLedForm(player, block) {
  if (formOpen.has(player.id)) return;
  formOpen.add(player.id);
  const isRgb = block.typeId === RGB_ID;
  const form = new ModalFormData().title(isRgb ? "RGB Panel" : "LED Lamp");
  if (isRgb) {
    const cur = block.permutation.getState(ST_COLOR) ?? "white";
    form.dropdown("Color", RGB_COLORS.map((c) => c.replace("_", " ")), { defaultValueIndex: Math.max(0, RGB_COLORS.indexOf(cur)) });
  }
  form.slider("Brightness", 1, 15, { valueStep: 1, defaultValue: block.permutation.getState(ST_BRIGHT) ?? 8 });
  form.dropdown("Power source", ["Redstone signal", "Battery (always on)"],
    { defaultValueIndex: block.permutation.getState(ST_BATTERY) === true ? 1 : 0 });
  form.submitButton("Apply");
  showForm(form, player).then((res) => {
    if (res.canceled || !res.formValues) return;
    const b = block.dimension.getBlock(block.location);
    if (!b || (b.typeId !== LED_ID && b.typeId !== RGB_ID)) return;
    const vals = res.formValues;
    let i = 0;
    let p = b.permutation;
    if (isRgb) p = p.withState(ST_COLOR, RGB_COLORS[vals[i++] | 0] ?? "white");
    const v = Math.max(1, Math.min(15, vals[i++] | 0));
    const battery = (vals[i++] | 0) === 1;
    b.setPermutation(p.withState(ST_BRIGHT, v).withState(ST_BATTERY, battery));
    ledEvaluate(b.dimension.getBlock(b.location));
  }).catch((err) => console.warn(`[evo74] led form failed: ${err}`))
    .finally(() => formOpen.delete(player.id));
}

world.beforeEvents.playerInteractWithBlock.subscribe((e) => {
  const { block, player, itemStack } = e;
  if (block.typeId !== LED_ID && block.typeId !== RGB_ID) return;
  if (itemStack !== undefined && !WRENCH_IDS.has(itemStack.typeId)) return;
  e.cancel = true;
  system.run(() => openLedForm(player, block));
});

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------
system.beforeEvents.startup.subscribe((ev) => {
  ev.blockComponentRegistry.registerCustomComponent(`${NS}:redstone_chain`, RedstoneComponent);
  ev.blockComponentRegistry.registerCustomComponent(`${NS}:elevator`, ElevatorComponent);
  ev.blockComponentRegistry.registerCustomComponent(`${NS}:led`, LedComponent);
  ev.blockComponentRegistry.registerCustomComponent(`${NS}:door`, DoorComponent);
  ev.blockComponentRegistry.registerCustomComponent(`${NS}:call_button`, CallButtonComponent);
});

world.afterEvents.worldLoad.subscribe(() => {
  for (const d of ["overworld", "nether", "the_end"]) {
    try { for (const e of world.getDimension(d).getEntities({ type: CAR_ENTITY })) e.remove(); } catch {}
    try { for (const e of world.getDimension(d).getEntities({ type: PANEL_ENTITY })) e.remove(); } catch {}
  }
  console.log("[evo74] custom components registered");
});
